#ifndef __KEY_H
#define __KEY_H

#include "sys.h"

#define KEY_1_PIN   PDin(7)
#define KEY_2_PIN   PBin(4)

void vKey_Init(void);

#endif
