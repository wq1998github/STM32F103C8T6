/**
  ******************************************************************************
  * File Name          : main.c
  * Description        : Main program body
  ******************************************************************************
  * This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether 
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * Copyright (c) 2017 STMicroelectronics International N.V. 
  * All rights reserved.
  *
  * Redistribution and use in source and binary forms, with or without 
  * modification, are permitted, provided that the following conditions are met:
  *
  * 1. Redistribution of source code must retain the above copyright notice, 
  *    this list of conditions and the following disclaimer.
  * 2. Redistributions in binary form must reproduce the above copyright notice,
  *    this list of conditions and the following disclaimer in the documentation
  *    and/or other materials provided with the distribution.
  * 3. Neither the name of STMicroelectronics nor the names of other 
  *    contributors to this software may be used to endorse or promote products 
  *    derived from this software without specific written permission.
  * 4. This software, including modifications and/or derivative works of this 
  *    software, must execute solely and exclusively on microcontroller or
  *    microprocessor devices manufactured by or for STMicroelectronics.
  * 5. Redistribution and use of this software other than as permitted under 
  *    this license is void and will automatically terminate your rights under 
  *    this license. 
  *
  * THIS SOFTWARE IS PROVIDED BY STMICROELECTRONICS AND CONTRIBUTORS "AS IS" 
  * AND ANY EXPRESS, IMPLIED OR STATUTORY WARRANTIES, INCLUDING, BUT NOT 
  * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
  * PARTICULAR PURPOSE AND NON-INFRINGEMENT OF THIRD PARTY INTELLECTUAL PROPERTY
  * RIGHTS ARE DISCLAIMED TO THE FULLEST EXTENT PERMITTED BY LAW. IN NO EVENT 
  * SHALL STMICROELECTRONICS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
  * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
  * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
  * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
  * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
  * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f4xx_hal.h"
#include "cmsis_os.h"

/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/
UART_HandleTypeDef huart2;
DMA_HandleTypeDef hdma_usart2_tx;
DMA_HandleTypeDef hdma_usart2_rx;

osThreadId RedLEDHandle;
osThreadId UART_RecvHandle;
osThreadId UART_SendHandle;
osMessageQId uart_recv_msgHandle;
osMessageQId led_msgHandle;
osTimerId myTimer01Handle;
osSemaphoreId uart_SemHandle;

/* USER CODE BEGIN PV */
/* Private variables ---------------------------------------------------------*/

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_USART2_UART_Init(void);
void RedLED_Task(void const * argument);
void UART_Recv_Task(void const * argument);
void UART_Send_Task(void const * argument);
void Callback01(void const * argument);

/* USER CODE BEGIN PFP */
/* Private function prototypes -----------------------------------------------*/

/* USER CODE END PFP */

/* USER CODE BEGIN 0 */
#define  T_SIZE   (sizeof(t_Rx))
#define  RECV_FLAG    0xAABB

#define  UART_CMD_1S      0x1111
#define  UART_CMD_500MS   0x2222
#define  UART_CMD_50MS    0x3333
#define  INVALID_CMD      0xFFFF

uint8_t  t_idle_flag = 0;
uint8_t  t_Tx[100] = {0};
uint8_t  t_Rx[100] = {0};
uint8_t  t_uart_buf[100] = {0};
  
uint8_t  uart_buf[100] = {0};
uint32_t uart_cnt = T_SIZE;
uint32_t uart_len = 0;

uint8_t  uart_tx_flag = 0;
     
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
   uart_tx_flag  =  1;
}

void  t_Error_handler(void)
{
    while(1);
}
/* USER CODE END 0 */

int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration----------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART2_UART_Init();

  /* USER CODE BEGIN 2 */
  /* USER CODE END 2 */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* Create the semaphores(s) */
  /* definition and creation of uart_Sem */
  osSemaphoreDef(uart_Sem);
  uart_SemHandle = osSemaphoreCreate(osSemaphore(uart_Sem), 1);

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* Create the timer(s) */
  /* definition and creation of myTimer01 */
  osTimerDef(myTimer01, Callback01);
  myTimer01Handle = osTimerCreate(osTimer(myTimer01), osTimerPeriodic, NULL);

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* Create the thread(s) */
  /* definition and creation of RedLED */
  osThreadDef(RedLED, RedLED_Task, osPriorityLow, 0, 128);
  RedLEDHandle = osThreadCreate(osThread(RedLED), NULL);

  /* definition and creation of UART_Recv */
  osThreadDef(UART_Recv, UART_Recv_Task, osPriorityHigh, 0, 256);
  UART_RecvHandle = osThreadCreate(osThread(UART_Recv), NULL);

  /* definition and creation of UART_Send */
  osThreadDef(UART_Send, UART_Send_Task, osPriorityNormal, 0, 256);
  UART_SendHandle = osThreadCreate(osThread(UART_Send), NULL);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  
  osTimerStart(myTimer01Handle, 10);   // 10ms timer.
  /* USER CODE END RTOS_THREADS */

  /* Create the queue(s) */
  /* definition and creation of uart_recv_msg */
  osMessageQDef(uart_recv_msg, 16, uint16_t);
  uart_recv_msgHandle = osMessageCreate(osMessageQ(uart_recv_msg), NULL);

  /* definition and creation of led_msg */
  osMessageQDef(led_msg, 16, uint16_t);
  led_msgHandle = osMessageCreate(osMessageQ(led_msg), NULL);

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */
 

  /* Start scheduler */
  osKernelStart();
  
  /* We should never get here as control is now taken by the scheduler */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
  /* USER CODE END WHILE */

  /* USER CODE BEGIN 3 */

  }
  /* USER CODE END 3 */

}

/** System Clock Configuration
*/
void SystemClock_Config(void)
{

  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;

    /**Configure the main internal regulator output voltage 
    */
  __HAL_RCC_PWR_CLK_ENABLE();

  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = 16;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure the Systick interrupt time 
    */
  HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);

    /**Configure the Systick 
    */
  HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);

  /* SysTick_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(SysTick_IRQn, 15, 0);
}

/* USART2 init function */
static void MX_USART2_UART_Init(void)
{

  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/** 
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void) 
{
  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Stream5_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream5_IRQn, 8, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream5_IRQn);
  /* DMA1_Stream6_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream6_IRQn, 9, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream6_IRQn);

}

/** Configure pins as 
        * Analog 
        * Input 
        * Output
        * EVENT_OUT
        * EXTI
*/
static void MX_GPIO_Init(void)
{

  GPIO_InitTypeDef GPIO_InitStruct;

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : LD2_Pin */
  GPIO_InitStruct.Pin = LD2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LD2_GPIO_Port, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/* RedLED_Task function */
void RedLED_Task(void const * argument)
{

  /* USER CODE BEGIN 5 */
  osEvent event1; 
  static  uint32_t last_cmd;
  /* Infinite loop */
  for(;;)
  {
     event1 = osMessageGet(led_msgHandle, 10);
     if( event1.status == osEventMessage )
     {
         last_cmd = event1.value.v;
     }
//     if( event1.status == osEventMessage )
     {
         
         switch(last_cmd)
         {
           case UART_CMD_1S:
               HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5);
               osDelay(1000); 
               break;
           case UART_CMD_500MS:
               HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5);
               osDelay(500);  
               break;
           case UART_CMD_50MS:
               HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5);
               osDelay(50);  
               break;
           default:
 //              HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5);
 //              osDelay(5000);
               break;
         }
     }
//     else
     {

     }

  }
  /* USER CODE END 5 */ 
}

/* UART_Recv_Task function */
void UART_Recv_Task(void const * argument)
{
  /* USER CODE BEGIN UART_Recv_Task */
  osEvent event1; 
    
  if(HAL_UART_Receive_DMA(&huart2, t_Rx, T_SIZE) != HAL_OK)
  {
      t_Error_handler();
  }
  
   if(osSemaphoreWait(uart_SemHandle , 0) != osOK)   // get semaphore to lock uart_send task.
   {
      t_Error_handler();
   }
  /* Infinite loop */
  for(;;)
  {

     event1 = osMessageGet(uart_recv_msgHandle, osWaitForever);
     if( event1.status == osEventMessage )
     {
         if(event1.value.v == RECV_FLAG)
         {
             // t_uart_buf cmd
           if(strcmp(t_uart_buf, "LED-1S") == 0)
           {
               if(osMessagePut (led_msgHandle, UART_CMD_1S, 100) != osOK)
               {
                   t_Error_handler();// err handler.
               }
           }
           else if(strcmp(t_uart_buf, "LED-500MS") == 0)
           {
               if(osMessagePut (led_msgHandle, UART_CMD_500MS, 100) != osOK)
               {
                   t_Error_handler();// err handler.
               }
           }
           else if(strcmp(t_uart_buf, "LED-50MS") == 0)
           {
               if(osMessagePut (led_msgHandle, UART_CMD_50MS, 100) != osOK)
               {
                   t_Error_handler();// err handler.
               }
           }
           else if(strcmp(t_uart_buf, "UART-RELEASE") == 0)
           {
               osSemaphoreRelease(uart_SemHandle);
           }
           else if(strcmp(t_uart_buf, "UART-LOCK") == 0)           
           {
               if(osSemaphoreWait(uart_SemHandle , 5000) != osOK)   // get semaphore to lock uart_send task.
               {
                  t_Error_handler();
               }
           }
           else
           {
               if(osMessagePut (led_msgHandle, INVALID_CMD, 100) != osOK)
               {
                   t_Error_handler();// err handler.
               }// invalid string, send "i don't understand you".
           }
           memset(t_uart_buf, 0, sizeof(t_uart_buf));
         
         }
     }
  }
  /* USER CODE END UART_Recv_Task */
}

/* UART_Send_Task function */
void UART_Send_Task(void const * argument)
{
  /* USER CODE BEGIN UART_Send_Task */
  /* Infinite loop */
  osDelay(1000);
  for(;;)
  {
      if(osSemaphoreWait(uart_SemHandle , 10) == osOK)
      {
          if(HAL_UART_Transmit_DMA(&huart2, "hello world!", sizeof("hello world!")) != HAL_OK)
          {
              t_Error_handler();
          }
          while(!uart_tx_flag); // here we simply use while to wait for tx complete.
          uart_tx_flag = 0;
          
          osDelay(1000);
          osSemaphoreRelease(uart_SemHandle);
      }
      else     // send "i'm locked" every 5S.
      {
          if(HAL_UART_Transmit_DMA(&huart2, "i'm locked", sizeof("i'm locked")) != HAL_OK)
          {
              t_Error_handler();
          }
          while(!uart_tx_flag); // here we simply use while to wait for tx complete.
          uart_tx_flag = 0;
          
          osDelay(5000);        
      }
  }
  /* USER CODE END UART_Send_Task */
}

/* Callback01 function */
void Callback01(void const * argument)
{
  /* USER CODE BEGIN Callback01 */
//  taskENTER_CRITICAL();     // in case there's uart receiver, in dma circular mode, no need.
  uint32_t  cur_cnt;
  uint32_t  i,j;
  cur_cnt = hdma_usart2_rx.Instance->NDTR;
  
  if(uart_cnt == cur_cnt)
  {
      // uart not received anything...do nothing.
  }
  else
  {
      if(uart_cnt > cur_cnt)
      {
         uart_len = uart_cnt - cur_cnt;
      }
      else
      {
        uart_len = uart_cnt+T_SIZE - cur_cnt;
      }

      for(i=0;i<uart_len;i++)
      {
         t_uart_buf[i] = t_Rx[(T_SIZE-uart_cnt + i)%T_SIZE];
      }
      
      if(osMessagePut (uart_recv_msgHandle, RECV_FLAG, 100) != osOK)
      {
         t_Error_handler();// err handler.
      }
  }
  
  uart_cnt = cur_cnt;  // refresh uart_cnt
  
//  taskEXIT_CRITICAL();

  /* USER CODE END Callback01 */
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @param  None
  * @retval None
  */
void _Error_Handler(char * file, int line)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  while(1) 
  {
  }
  /* USER CODE END Error_Handler_Debug */ 
}

#ifdef USE_FULL_ASSERT

/**
   * @brief Reports the name of the source file and the source line number
   * where the assert_param error has occurred.
   * @param file: pointer to the source file name
   * @param line: assert_param error line source number
   * @retval None
   */
void assert_failed(uint8_t* file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
    ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */

}

#endif

/**
  * @}
  */ 

/**
  * @}
*/ 

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
